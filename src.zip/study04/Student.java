package study04;

public class Student {
	public String getBmi(String name, double height, double weight) {
		
		
		String result ="";
		
		return result;
		
	}
	
	public String unknown(String name, String adress, int age, int balance, int belif) {
		
		return "1억대출가능";
		
	}

}
